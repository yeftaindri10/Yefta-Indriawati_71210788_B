LLNC = DoubleLList()
DLLNC.addElementTail('Shalom',3.9)
DLLNC.addElementTail('Nabilla',3.8)
DLLNC.addElementTail('Kurniadi',3.7)
DLLNC.addElementTail('Harris',3.6)
DLLNC.printDescending()

DLLNC.deleteLast()
DLLNC.printDescending()

DLLNC.rataIpk()
