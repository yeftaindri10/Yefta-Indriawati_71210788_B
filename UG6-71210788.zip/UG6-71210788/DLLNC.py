from NodeMahasiswa import NodeMahasiswa

class DLLNC:
       def _init_(self):
              self.head = None
              self.tail = None
              self.size = 0
        
       def isEmpty(self):
            return self.size == 0

       def __len__(self):
              return self.size == 0

       def addElementTail(self,nama,ipk):
              baru = NodeMahasiswa(nama,ipk)
              if self.size == 0:
                     self.head = baru
                     self.tail = baru
              else:
                     self.tail = baru
                     baru.prev = self.tail
                     self.tail = baru
              print("data masuk dari belakang")
              self.size = self.size + 1
       def deleteLast(self):
              if self.isEmpty() == False:
                     d = None
                     bantu = self._head
                     if(self._head._next != None):
                            hapus = self._tail
                            self._tail = self._tail._prev
                            d = hapus._element
                            self._tail._next = None
                            del hapus
                     else:
                            d = self._tail._element
                            self._head=tail=None
                     self._size -= 1
                     print(d, " terhapus!")
              else:
                     print("Kosong!")

       def printAllDescending(self):
              bantu = self.tail 
              print("===== Print Descending =====") 

       while bantu != None : 
            print("=" * 20) 
            print("Nama:", bantu._element) 
            print("IPK: ", bantu._ipk) 
            bantu = bantu._prev

       def rataIpk(self):
              pass
